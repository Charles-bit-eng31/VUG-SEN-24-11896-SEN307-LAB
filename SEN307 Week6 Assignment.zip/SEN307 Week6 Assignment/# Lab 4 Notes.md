# Lab 4 Notes

## Referential Integrity

**1. What error occurred?**

MySQL Error 1451 occurred when I attempted to delete the Library and Information Science department.

**2. Why did MySQL refuse to delete it?**

The department was referenced by a student record in the Student table. The foreign key constraint prevented deletion because the student still depended on that department.

**3. How was the problem fixed?**

I reassigned the transfer student to the Software Engineering department. I then successfully deleted the temporary department.

**4. What other solution could have been used?**

The student record could have been deleted before deleting the department. However, reassignment allowed me to preserve the student record.