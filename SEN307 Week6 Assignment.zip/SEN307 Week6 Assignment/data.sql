USE sen307_11896;
SELECT 'Departments' AS tbl, COUNT(*) AS total FROM Department
UNION ALL
SELECT 'Lecturers', COUNT(*) FROM Lecturer
UNION ALL
SELECT 'Students', COUNT(*) FROM Student
UNION ALL
SELECT 'Courses', COUNT(*) FROM Course
UNION ALL
SELECT 'Enrolments', COUNT(*) FROM Enrolment
UNION ALL
SELECT 'Allocations', COUNT(*) FROM CourseAllocation;


-- =========================================
-- LAB 4: PART 3 - UPDATING STUDENT DEPARTMENT
-- =========================================

-- Check student's original department
SELECT matric_no, full_name, dept_id
FROM Student
WHERE matric_no = 'VUG/SEN/24/11896';

-- Move student to Computer Science (dept_id 3)
SET SQL_SAFE_UPDATES = 0;

UPDATE Student
SET dept_id = 3
WHERE matric_no = 'VUG/SEN/24/11896';

SET SQL_SAFE_UPDATES = 1;

-- Verify the update
SELECT matric_no, full_name, dept_id
FROM Student
WHERE matric_no = 'VUG/SEN/24/11896';


-- =========================================
-- LAB 4: PART 4 - REFERENTIAL INTEGRITY
-- =========================================

-- Create temporary department
INSERT INTO Department (dept_name)
VALUES ('Library and Information Science');

-- Add transfer student
INSERT INTO Student
(matric_no, full_name, gender, date_of_birth, dept_id)
VALUES
('20239999', 'Transfer Student', 'M', '2005-05-15',
 (SELECT dept_id FROM Department
  WHERE dept_name = 'Library and Information Science'));

-- Attempt to delete department (Error 1451 expected)
DELETE FROM Department
WHERE dept_name = 'Library and Information Science';

-- Reassign student to Software Engineering
SET SQL_SAFE_UPDATES = 0;

UPDATE Student
SET dept_id = (
    SELECT dept_id FROM Department
    WHERE dept_name = 'Software Engineering'
)
WHERE matric_no = '20239999';

-- Delete temporary department
DELETE FROM Department
WHERE dept_name = 'Library and Information Science';

SET SQL_SAFE_UPDATES = 1;

-- Verify remaining departments
SELECT * FROM Department;