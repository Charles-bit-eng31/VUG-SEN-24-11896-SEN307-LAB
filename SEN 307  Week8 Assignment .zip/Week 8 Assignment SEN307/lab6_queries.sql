USE sen307_11896;

SHOW TABLES;USE sen307_11896;

-- LAB 6: TASK 1
-- Count students enrolled in each course,
-- including courses with zero students.

SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
ORDER BY total_students DESC;


-- LAB 6: TASK 2
-- Find courses with more than 3 students

SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 3
ORDER BY total_students DESC;


-- Find courses with more than 5 students

SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 5
ORDER BY total_students DESC;


-- Find courses with more than 7 students

SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 7
ORDER BY total_students DESC;



-- LAB 6: TASK 3
-- Calculate the average number of courses per student,
-- including students with zero courses.

SELECT ROUND(AVG(course_count), 2) AS average_courses
FROM (
    SELECT
        s.student_id,
        COUNT(e.course_id) AS course_count
    FROM Student s
    LEFT JOIN Enrolment e
        ON s.student_id = e.student_id
    GROUP BY s.student_id
) AS per_student;




-- LAB 6: TASK 4
-- Find students who are not enrolled in any course.

SELECT full_name, matric_no
FROM Student
WHERE student_id NOT IN (
    SELECT student_id
    FROM Enrolment
)
ORDER BY full_name;





-- LAB 6: TASK 5
-- Find the student(s) with the highest number
-- of enrolments in each department.

SELECT
    d.dept_name,
    s.full_name,
    (
        SELECT COUNT(*)
        FROM Enrolment e
        WHERE e.student_id = s.student_id
    ) AS courses
FROM Student s
JOIN Department d
    ON s.dept_id = d.dept_id
WHERE (
    SELECT COUNT(*)
    FROM Enrolment e
    WHERE e.student_id = s.student_id
) = (
    SELECT COUNT(*)
    FROM Student s2
    JOIN Enrolment e2
        ON s2.student_id = e2.student_id
    WHERE s2.dept_id = s.dept_id
    GROUP BY s2.student_id
    ORDER BY COUNT(*) DESC
    LIMIT 1
)
ORDER BY d.dept_name;